This is the readme for the Wallace demo Rogers. It explores the evolution of asocial learning and unguided social learning in the context of a numerical discrimination task.
