This is a networked coordination game where players broadcast messages to eachother and try to make the same decision as others.
