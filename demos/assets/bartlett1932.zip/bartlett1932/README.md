This is the readme for Bartlett's 1932 experiment on iterated learning. It used 'The War of the Ghosts' story.

Bartlett, F. C. (1932). Remembering. Cambridge: Cambridge University Press.

[Download the demo](assets/bartlett1932.zip).
